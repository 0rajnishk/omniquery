add excel file in the data folder

run 
```bash
python excel_to_sqlite.py <excel_file_path> <sqlite_db_path>
```