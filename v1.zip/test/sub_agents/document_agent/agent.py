from google.adk.agents import Agent

document_agent = Agent(
    name="document_agent",
    model="gemini-2.0-flash",
    description="Document agent for document processing",
    instruction="I am document agent",
    sub_agents=[],
    tools=[],
) 