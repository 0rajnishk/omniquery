from google.adk.agents import Agent

sql_agent = Agent(
    name="sql_agent",
    model="gemini-2.0-flash",
    description="SQL agent for database queries",
    instruction="I am sql_agent",
    sub_agents=[],
    tools=[],
) 